<?php
$url = $_GET['q'];
$handle = curl_init($url);
curl_setopt($handle, CURLOPT_HTTPHEADER, array(
    'content-type' => 'application/x-www-form-urlencoded'
));
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
//curl_setopt($handle, CURLOPT_POST, true);

$response = curl_exec($handle);
print $response;